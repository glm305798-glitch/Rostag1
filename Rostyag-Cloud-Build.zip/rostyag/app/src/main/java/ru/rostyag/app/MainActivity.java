package ru.rostyag.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import rikka.shizuku.Shizuku;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 7341;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status;
    private Button applyButton;
    private String pendingCommand = null;
    private boolean waitingForPermission = false;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQUEST_CODE) return;
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            setStatus("Shizuku разрешён. Нажми нужную кнопку ещё раз.");
        } else {
            setStatus("Доступ Shizuku не выдан. Разреши доступ в окне Shizuku.");
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(0xFFF4F6FB);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Ростяг"); title.setTextSize(30); title.setTextColor(0xFF17213A);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Настройка экрана • Xiaomi 11 Lite 5G NE"); subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF596579); subtitle.setPadding(0, dp(5), 0, dp(18)); root.addView(subtitle);

        TextView warning = new TextView(this);
        warning.setText("Важно: параметры меняются для всего Android, а не только для игры. Некоторые игры могут сохранить чёрные полосы. Начни с безопасного профиля и при необходимости нажми «Вернуть исходное». ");
        warning.setTextSize(14); warning.setTextColor(0xFF714B00); warning.setPadding(dp(14), dp(12), dp(14), dp(12));
        warning.setBackgroundColor(0xFFFFF0CC); root.addView(warning, params(-1, -2, 0, 0, 0, dp(16)));

        TextView label = section("Профиль разрешения"); root.addView(label);
        root.addView(makeProfile("Сбалансированный — 2160 × 1080", "wm size 2160x1080", "Умеренное изменение ширины"));
        root.addView(makeProfile("Широкий — 2280 × 1080", "wm size 2280x1080", "Ближе к исходным 20:9"));
        root.addView(makeProfile("16:9 — 1920 × 1080", "wm size 1920x1080", "Сильное изменение; возможны обрезка или полосы"));

        Button restore = button("Вернуть исходное разрешение", 0xFF26344F);
        restore.setOnClickListener(v -> runShell("wm size reset", "Исходное разрешение восстановлено."));
        root.addView(restore, params(-1, dp(54), 0, dp(8), 0, 0));

        status = new TextView(this); status.setText("Статус: ожидается подключение Shizuku"); status.setTextColor(0xFF26344F);
        status.setTextSize(14); status.setPadding(0, dp(18), 0, dp(6)); root.addView(status);
        TextView steps = new TextView(this);
        steps.setText("Как пользоваться:\n1. Запусти Shizuku и включи беспроводную отладку, если этого требует твоя версия Android.\n2. Выдай приложению доступ Shizuku.\n3. Применяй профиль и проверяй игру.\n4. После игры нажми «Вернуть исходное разрешение».\n\nЕсли экран выглядит неправильно, подожди несколько секунд или перезапусти телефон — команда wm size reset сбрасывает переопределение разрешения.");
        steps.setTextSize(14); steps.setTextColor(0xFF596579); steps.setPadding(0, dp(10), 0, 0); root.addView(steps);
        setContentView(scroll);
    }

    private View makeProfile(String title, String command, String detail) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14)); card.setBackgroundColor(0xFFFFFFFF);
        TextView t = new TextView(this); t.setText(title); t.setTextColor(0xFF17213A); t.setTextSize(16); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); card.addView(t);
        TextView d = new TextView(this); d.setText(detail); d.setTextColor(0xFF68748A); d.setTextSize(13); d.setPadding(0, dp(4), 0, dp(10)); card.addView(d);
        Button b = button("Применить профиль", 0xFF3867F4); b.setOnClickListener(v -> runShell(command, "Команда отправлена: " + title)); card.addView(b);
        LinearLayout.LayoutParams lp = params(-1, -2, 0, 0, 0, dp(10)); card.setElevation(dp(1)); card.setLayoutParams(lp); return card;
    }

    private TextView section(String text) { TextView v = new TextView(this); v.setText(text); v.setTextColor(0xFF17213A); v.setTextSize(18); v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); v.setPadding(0, 0, 0, dp(10)); return v; }
    private Button button(String text, int color) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b; }
    private LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.setMargins(l,t,r,b); return p; }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    private void runShell(String command, String successMessage) {
        try {
            if (Shizuku.getBinder() == null || !Shizuku.pingBinder()) {
                setStatus("Shizuku не запущен. Открой Shizuku и запусти службу."); return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Запрашиваем разрешение Shizuku…");
                Shizuku.requestPermission(REQUEST_CODE); return;
            }
            setStatus("Выполняется команда…");
            executor.execute(() -> {
                StringBuilder out = new StringBuilder();
                try {
                    Process p = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String line; while ((line = reader.readLine()) != null) out.append(line).append('\n');
                    BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                    while ((line = err.readLine()) != null) out.append(line).append('\n');
                    int code = p.waitFor();
                    final String result = code == 0 ? successMessage : "Команда завершилась с кодом " + code + (out.length() > 0 ? ": " + out : "");
                    main.post(() -> setStatus(result));
                } catch (Exception e) { main.post(() -> setStatus("Ошибка Shizuku: " + e.getMessage())); }
            });
        } catch (Exception e) { setStatus("Не удалось обратиться к Shizuku: " + e.getMessage()); }
    }
    private void setStatus(String text) { if (status != null) status.setText("Статус: " + text); }
    @Override protected void onDestroy() { Shizuku.removeRequestPermissionResultListener(permissionListener); executor.shutdownNow(); super.onDestroy(); }
}
