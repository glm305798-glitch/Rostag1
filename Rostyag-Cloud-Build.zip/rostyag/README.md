# Ростяг — Android project

Русскоязычный прототип для изменения логического разрешения Android через Shizuku (без root). Включает профили 2160×1080, 2280×1080, 1920×1080 и сброс `wm size reset`.

## Важно
- Приложение изменяет размер дисплея глобально, а не отдельно для Arena Breakout Mobile или Oxide: Survival Island.
- Это не гарантирует растягивание изображения в конкретной игре: игра/MIUI может ограничивать aspect ratio или показывать полосы.
- Перед применением запусти Shizuku, выдай разрешение приложению. Не меняй плотность (DPI) этим прототипом.
- «Вернуть исходное разрешение» выполняет `wm size reset`.

## Сборка APK
1. Открой проект в Android Studio на компьютере.
2. Дождись синхронизации Gradle и загрузки зависимости Shizuku API.
3. Выбери Build → Build APK(s).
4. APK обычно находится в `app/build/outputs/apk/debug/app-debug.apk`.

Нужны Android SDK Platform 35 и JDK 17. Проект использует Android Gradle Plugin 8.7.3 и Shizuku API 13.1.5.
